//
//  UnsplashPracticeApp.swift
//  UnsplashPractice
//
//  Created by 최유림 on 2020/11/26.
//

import SwiftUI

@main
struct UnsplashPracticeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
