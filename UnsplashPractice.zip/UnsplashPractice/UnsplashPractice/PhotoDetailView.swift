//
//  PhotoDetailView.swift
//  UnsplashPractice
//
//  Created by 최유림 on 2020/11/28.
//

import SwiftUI

struct PhotoDetailView: View {
    
    
    
    
    var body: some View {

            Text("Hello, World!")

    }
}

struct PhotoDetailView_Previews: PreviewProvider {
    static var previews: some View {
        PhotoDetailView()
    }
}
